import mysql from "mysql2/promise";
import { configDotenv } from "dotenv";

configDotenv();

const pool = {
    host: process.env.HOST,
    user: process.env.USER,
    password: process.env.PASSWORD,
    database: process.env.DATABASE,
}

export { pool };
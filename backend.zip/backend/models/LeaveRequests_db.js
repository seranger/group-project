import { pool } from "../config/config";

const getAllLeaveRequests = async () => {
    let [data] = await pool.query('SELECT * FROM leave_requests');
    return data;
}

const getLeaveRequest = async (Leave_RequestID) => {
    let [data] = await pool.query('SELECT * FROM leave_requests WHERE leave_requestID = ?', [Leave_RequestID]);
    return data;
}

const addLeaveRequest = async (Leave_RequestID,employeeID,date,reason,leave_status) => {
    let [data] = await pool.query('INSERT INTO leave_requests (leave_requestID,employeeID,date,reason,leave_status) SET (?,?,?,?,?)', [Leave_RequestID,employeeID,date,reason,leave_status]);
    return data;
}

const deleteLeaveRequest = async (leave_requestID) => {
    await pool.query('DELETE FROM employees WHERE leave_requestID = ?', [leave_requestID]);
    console.log(getAllLeaveRequests());
}

const updateLeaveRequest = async (leave_requestID,employeeID,date,reason,leave_status) => {
    let [data] = await pool.query('UPDATE leave_requests SET employeeID = ?, date = ?, reason = ?, leave_status = ? WHERE leave_requestID = ?', [employeeID,date,reason,leave_status,leave_requestID]);
    return data;
}
import { pool } from "../config/config";

const getAllPayroll = async () => {
    let [data] = await pool.query('SELECT * FROM payroll');
    return data;
}

const getPayroll = async (payroll_ID) => {
    let [data] = await pool.query('SELECT * FROM payroll WHERE payrollID = ?', [payroll_ID]);
    return data;
}

const addPayroll = async (payroll_ID,employeeID,hours_worked,leave_deductions,final_salary,performance) => {
    let [data] = await pool.query('INSERT INTO payroll (payroll_ID,employeeID,hours_worked,leave_deductions,final_salary,performance) SET (?,?,?,?,?,?)', [payroll_ID,employeeID,hours_worked,leave_deductions,final_salary,performance]);
    return data;
}

const deletePayroll = async (payroll_ID) => {
    await pool.query('DELETE FROM payroll WHERE employeeID = ?', [payroll_ID]);
    console.log(getAllPayroll());
}

const updateLeaveRequest = async (payroll_ID,employeeID,hours_worked,leave_deductions,final_salary,performance) => {
    let [data] = await pool.query('UPDATE payroll SET employeeID = ?, hours_worked = ?, leave_deductions = ?, final_salary = ?, performance = ? WHERE payroll_ID = ?', [employeeID,hours_worked,leave_deductions,final_salary,performance,payroll_ID]);
    return data;
}
import { pool } from "../config/config";

const getAllEmployees = async () => {
    let [data] = await pool.query('SELECT * FROM employees');
    return data;
}

const getEmployee = async (employeeID) => {
    let [data] = await pool.query('SELECT * FROM employees WHERE employeeID = ?', [employeeID]);
    return data;
}

const addEmployee = async (employeeID,name,position,salary,contact,department) => {
    let [data] = await pool.query('INSERT INTO employees (employeeID,name,position,salary,contact,department) SET (?,?,?,?,?,?)', [employeeID,name,position,salary,contact,department]);
    return data;
}

const deleteEmployee = async (employeeID) => {
    await pool.query('DELETE FROM employees WHERE employeeID = ?', [employeeID]);
    console.log(getAllEmployees());
}

const updateEmployee = async (employeeID,name,position,salary,contact,department) => {
    let [data] = await pool.query('UPDATE employees SET name = ?, position = ?, salary = ?, contact = ?, department = ? WHERE employeeID = ?', [name,position,salary,contact,department,employeeID]);
    return data;
}
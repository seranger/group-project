import { pool } from "../config/config";

const getAllAttendance = async () => {
    let [data] = await pool.query('SELECT * FROM attendance');
    return data;
}

const getAttendance = async (employeeID) => {
    let [data] = await pool.query('SELECT * FROM attendance WHERE employeeID = ?', [employeeID]);
    return data;
}

const addAttendance = async (employeeID,date,attendance_Status) => {
    let [data] = await pool.query('INSERT INTO attendance (employeeID,date,attendance_Status) SET (?,?,?)', [employeeID,date,attendance_Status]);
    return data;
}

const deleteAttendance = async (employeeID) => {
    await pool.query('DELETE FROM attendance WHERE employeeID = ?', [employeeID]);
    console.log(getAllAttendance());
}

const updateAttendance = async (date,attendance_Status,employeeID) => {
    let [data] = await pool.query('UPDATE attendance SET date = ?, attendance_Status = ? WHERE employeeID = ?', [date,attendance_Status,employeeID]);
    return data;
}
import { getAllEmployees, getEmployee, addEmployee, updateEmployee, deleteEmployee } from "../models/Employee_db.js";

const getAllEmployeesCon = async(req,res)=>{
    res.json(await getAllEmployees());
}

const getEmployeeCon = async(req,res)=>{
    res.json(await getEmployee(req.params.employeeID));
}

const addEmployeeCon = async(req,res)=>{
    let {employeeID,name,position,salary,contact,department} = req.body; 
    console.log(req.body);
    res.json({
    employee: await addEmployee(employeeID,name,position,salary,contact,department)
    });
}

const deleteEmployeeCon = async(req,res)=>{
    res.json({
    employee: await deleteEmployee(req.params.employeeID)
    });
}

const updateEmployeeCon = async(req,res)=>{
    let {name,position,salary,contact,department,employeeID} = req.body; 
    console.log(req.body);
    res.json({
    employee: await updateEmployee(name,position,salary,contact,department,employeeID)
    });
}

export {getAllEmployeesCon,getEmployeeCon,addEmployeeCon,deleteEmployeeCon,updateEmployeeCon};
import { getAllAttendance, getAttendance, addAttendance, deleteAttendance, updateAttendance } from "../models/Attendance_db.js";

const getAllAttendanceCon = async(req,res)=>{
    res.json(await getAllAttendance());
}

const getAttendanceCon = async(req,res)=>{
    res.json(await getAttendance(req.params.employeeID));
}

const addAttendanceCon = async(req,res)=>{
    let {employeeID,date,attendance_Status} = req.body; 
    console.log(req.body);
    res.json({
    attendance: await addAttendance(employeeID,date,attendance_Status)
    });
}

const deleteAttendanceCon = async(req,res)=>{
    res.json({
    attendance: await deleteAttendance(req.params.employeeID)
    });
}

const updateAttendanceCon = async(req,res)=>{
    let {date,attendance_Status,employeeID} = req.body; 
    console.log(req.body);
    res.json({
    attendance: await updateAttendance(date,attendance_Status,employeeID)
    });
}

export {getAllAttendanceCon,getAttendanceCon,addAttendanceCon,deleteAttendanceCon,updateAttendanceCon};
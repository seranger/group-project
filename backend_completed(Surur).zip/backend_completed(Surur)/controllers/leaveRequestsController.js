import { getAllLeaveRequests, getLeaveRequest, addLeaveRequest, updateLeaveRequest, deleteLeaveRequest } from "../models/LeaveRequests_db.js";

const getAllLeaveRequestsCon = async(req,res)=>{
    res.json(await getAllLeaveRequests());
}

const getLeaveRequestCon = async(req,res)=>{
    res.json(await getLeaveRequest(req.params.leave_requestID));
}

const addLeaveRequestCon = async(req,res)=>{
    let {Leave_RequestID,employeeID,date,reason,leave_status} = req.body; 
    console.log(req.body);
    res.json({
    leaveRequest: await addLeaveRequest(Leave_RequestID,employeeID,date,reason,leave_status)
    });
}

const deleteLeaveRequestCon = async(req,res)=>{
    res.json({
    leaveRequest: await deleteLeaveRequest(req.params.leave_requestID)
    });
}

const updateLeaveRequestCon = async(req,res)=>{
    let {employeeID,date,reason,leave_status,leave_requestID} = req.body; 
    console.log(req.body);
    res.json({
    leaveRequest: await updateLeaveRequest(employeeID,date,reason,leave_status,leave_requestID)
    });
}

export {getAllLeaveRequestsCon,getLeaveRequestCon,addLeaveRequestCon,deleteLeaveRequestCon,updateLeaveRequestCon};
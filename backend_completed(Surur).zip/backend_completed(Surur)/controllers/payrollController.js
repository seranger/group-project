import { getAllPayroll, getPayroll, addPayroll, deletePayroll, updatePayroll } from "../models/Payroll_db.js";

const getAllPayrollCon = async(req,res)=>{
    res.json(await getAllPayroll());
}

const getPayrollCon = async(req,res)=>{
    res.json(await getPayroll(req.params.employeeID));
}

const addPayrollCon = async(req,res)=>{
    let {payroll_ID,employeeID,hours_worked,leave_deductions,final_salary,performance} = req.body; 
    console.log(req.body);
    res.json({
    payroll: await addPayroll(payroll_ID,employeeID,hours_worked,leave_deductions,final_salary,performance)
    });
}

const deletePayrollCon = async(req,res)=>{
    res.json({
    payroll: await deletePayroll(req.params.employeeID)
    });
}

const updatePayrollCon = async(req,res)=>{
    let {employeeID,hours_worked,leave_deductions,final_salary,performance,payroll_ID} = req.body; 
    console.log(req.body);
    res.json({
    payroll: await updatePayroll(employeeID,hours_worked,leave_deductions,final_salary,performance,payroll_ID)
    });
}

export {getAllPayrollCon,getPayrollCon,addPayrollCon,deletePayrollCon,updatePayrollCon};